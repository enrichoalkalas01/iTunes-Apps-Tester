import React from 'react'
import Axios from 'axios'

class MusicPlayer extends React.Component {
    render() {
        return(
            <section id="music-player"> 
                <div className="wrapper-music-player">
                    
                </div>
            </section>
        )
    }
}

export default MusicPlayer